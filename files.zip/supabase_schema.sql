-- Run this entire block in Supabase → SQL Editor → New Query

create table public.profiles (
  id uuid references auth.users on delete cascade primary key,
  username text unique not null,
  created_at timestamptz default now()
);

create table public.progress (
  id uuid references auth.users on delete cascade primary key,
  xp integer not null default 0,
  streak integer not null default 0,
  last_day text,
  completed_lessons jsonb not null default '{}',
  cards_learned integer not null default 0,
  skills jsonb not null default '{"vocab":10,"grammar":8,"listening":6,"reading":7,"pronunciation":5}',
  speech_rate numeric not null default 1,
  updated_at timestamptz default now()
);

alter table public.profiles enable row level security;
alter table public.progress enable row level security;

create policy "own profile select" on public.profiles for select using (auth.uid() = id);
create policy "own profile insert" on public.profiles for insert with check (auth.uid() = id);
create policy "own profile update" on public.profiles for update using (auth.uid() = id);

create policy "own progress select" on public.progress for select using (auth.uid() = id);
create policy "own progress insert" on public.progress for insert with check (auth.uid() = id);
create policy "own progress update" on public.progress for update using (auth.uid() = id);
